<?php

namespace App\Onix\Blocks;

use Mariojgt\Onix\Helpers\BaseOnixBlocks;

class Home extends BaseOnixBlocks
{
    public string $template = 'luxgamers';
    public string $componentId = 'Home';
    public string $label = 'Home';
    public string $mediaPath = 'Home-media';
    public string $contentPath = 'Home';
    public string $category = 'blocks';
}
