<?php

namespace App\Onix\Blocks;

use Mariojgt\Onix\Helpers\BaseOnixBlocks;

class ProductPage extends BaseOnixBlocks
{
    public string $template = 'luxgamers';
    public string $componentId = 'ProductPage';
    public string $label = 'ProductPage';
    public string $mediaPath = 'ProductPage-media';
    public string $contentPath = 'ProductPage';
    public string $category = 'blocks';
}
