<?php

namespace App\Onix\Blocks;

use Mariojgt\Onix\Helpers\BaseOnixBlocks;

class Contact extends BaseOnixBlocks
{
    public string $template = 'luxgamers';
    public string $componentId = 'Contact';
    public string $label = 'Contact';
    public string $mediaPath = 'Contact-media';
    public string $contentPath = 'Contact';
    public string $category = 'blocks';
}
