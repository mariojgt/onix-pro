<?php

namespace App\Onix\Blocks;

use Mariojgt\Onix\Helpers\BaseOnixBlocks;

class Shop extends BaseOnixBlocks
{
    public string $template = 'luxgamers';
    public string $componentId = 'Shop';
    public string $label = 'Shop';
    public string $mediaPath = 'Shop-media';
    public string $contentPath = 'Shop';
    public string $category = 'blocks';
}
